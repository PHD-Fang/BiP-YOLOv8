import torch
from thop import profile
class CAN(torch.nn.Module):
    def __init__(self, in_channels, channels_1, channels_2, kernel_size=3, dropout_1=0.25, dropout_2=0.5,
                 pool_size=2, linear_in_channels=3136, linear_out_channels=128):
        super().__init__()
        self.m_appearance_model = AppearanceModel(in_channels, channels_1, channels_2, kernel_size, dropout_1,
                                                  pool_size)
        self.m_motion_model = MotionModel(in_channels, channels_1, channels_2, kernel_size, dropout_1, pool_size)
        self.m_linear_model = LinearModel(linear_in_channels, linear_out_channels, dropout_2)
        self.m_attention_mask1 = None
        self.m_attention_mask2 = None

    def forward(self, x):
        x = x.squeeze(0)
        x = torch.transpose(x, 1, 2)
        x = torch.chunk(x, 2, dim=0)
        self.m_attention_mask1, self.m_attention_mask2 = self.m_appearance_model(x[0].squeeze())
        motion_output = self.m_motion_model(x[1].squeeze(), self.m_attention_mask1, self.m_attention_mask2)
        out = self.m_linear_model(motion_output)

        return torch.transpose(out, 0, 1)

class AppearanceModel(torch.nn.Module):
    def __init__(self, in_channels, channels_1, channels_2, kernel_size=3, dropout=0.25, pool_size=2):
        # Appearance model
        super().__init__()
        self.m_block_1 = torch.nn.Sequential(
            torch.nn.Conv2d(in_channels=in_channels,
                            out_channels=channels_1,
                            kernel_size=kernel_size,
                            padding=(kernel_size - 1) // 2),
            torch.nn.Tanh(),
            torch.nn.Conv2d(in_channels=channels_1,
                            out_channels=channels_1,
                            kernel_size=kernel_size,
                            padding=0),
            torch.nn.Tanh()
        )

        self.m_block_2 = torch.nn.Sequential(
            torch.nn.Conv2d(in_channels=channels_1,
                            out_channels=channels_2,
                            kernel_size=kernel_size,
                            padding=(kernel_size - 1) // 2),
            torch.nn.Tanh(),
            torch.nn.Conv2d(in_channels=channels_2,
                            out_channels=channels_2,
                            kernel_size=kernel_size,
                            padding=0),
            torch.nn.Tanh()
        )
        self.m_attention_1 = AttentionBlock(channels_1)
        self.m_attention_2 = AttentionBlock(channels_2)
        self.m_avg_pool = torch.nn.AvgPool2d(kernel_size=pool_size)
        self.m_dropout = torch.nn.Dropout2d(dropout)

    def forward(self, x):
        x = self.m_block_1(x)
        mask_1 = self.m_attention_1(x)
        x = self.m_avg_pool(x)
        x = self.m_dropout(x)
        x = self.m_block_2(x)
        mask_2 = self.m_attention_2(x)
        return mask_1, mask_2

class MotionModel(torch.nn.Module):
    def __init__(self, in_channels, channels_1, channels_2, kernel_size=3, dropout=0.25, pool_size=2):
        # Motion model
        super().__init__()
        self.m_block_1 = torch.nn.Sequential(
            torch.nn.Conv2d(in_channels=in_channels,
                            out_channels=channels_1,
                            kernel_size=kernel_size,
                            padding=(kernel_size - 1) // 2),
            torch.nn.Tanh(),
            torch.nn.Conv2d(in_channels=channels_1,
                            out_channels=channels_1,
                            kernel_size=kernel_size,
                            padding=0),
            torch.nn.Tanh()
        )

        self.m_block_2 = torch.nn.Sequential(
            torch.nn.Conv2d(in_channels=channels_1,
                            out_channels=channels_2,
                            kernel_size=kernel_size,
                            padding=(kernel_size - 1) // 2),
            torch.nn.Tanh(),
            torch.nn.Conv2d(in_channels=channels_2,
                            out_channels=channels_2,
                            kernel_size=kernel_size,
                            padding=0),
            torch.nn.Tanh()
        )
        self.m_avg_pool_1 = torch.nn.AvgPool2d(kernel_size=pool_size)
        self.m_dropout_1 = torch.nn.Dropout2d(dropout)
        self.m_avg_pool_2 = torch.nn.AvgPool2d(kernel_size=pool_size)
        self.m_dropout_2 = torch.nn.Dropout2d(dropout)

    def forward(self, x, mask_1, mask_2):
        x = self.m_block_1(x)
        x = x * mask_1
        x = self.m_avg_pool_1(x)
        x = self.m_dropout_1(x)
        x = self.m_block_2(x)
        x = x * mask_2
        x = self.m_avg_pool_2(x)
        x = self.m_dropout_2(x)
        return x

class AttentionBlock(torch.nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.attention = torch.nn.Conv2d(in_channels, 1, kernel_size=1,  padding=0)

    def forward(self, x):
        mask = self.attention(x)
        mask = torch.sigmoid(mask)
        B, C, H, W = x.shape
        norm = 2 * torch.norm(mask, p=1, dim=(1, 2, 3))
        norm = norm.reshape(B, 1, 1, 1)
        mask = torch.div(mask * H * W, norm)
        return mask

class LinearModel(torch.nn.Module):
    def __init__(self, in_channel, out_channel, dropout=0.5):
        super().__init__()
        self.m_block = torch.nn.Sequential(
            torch.nn.Flatten(start_dim=1),
            torch.nn.Linear(in_channel, out_channel, bias=True),
            torch.nn.Tanh(),
            torch.nn.Dropout(dropout),
            torch.nn.Linear(out_channel, 1, bias=True)
        )

    def forward(self, x):
        x = self.m_block(x)
        return x


if __name__ == '__main__':
    from utils.utils import weights_init
    import time
    device = torch.device('cuda:0'
    )
    img = torch.rand(1, 2, 3, 256, 72, 72).to(device)  # [batch, norm + diff, channel, width, height]
    net = CAN(3, 32, 64, linear_in_channels=16384).to(device)
    weights_init(net)
    out = net(img)  # [batch, 1]
    t1 = time.time()
    for _ in range(100):
        out = net(img)  # [batch, 1]
    t2 = time.time()
    print((t2-t1)/100)
    flops, params = profile(net, inputs=(img,))
    print(flops)
    print(params)