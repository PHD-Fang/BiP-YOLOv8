import torch
from thop import profile
import numpy as np


def autopad(k, p=None, d=1):
    # kernel, padding, dilation
    # 对输入的特征层进行自动padding，按照Same原则
    if d > 1:
        # actual kernel-size
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        # auto-pad
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p

class SiLU(torch.nn.Module):
    # SiLU激活函数
    @staticmethod
    def forward(x):
        return x * torch.sigmoid(x)


class Conv(torch.nn.Module):
    # default_act = SiLU()
    default_act = torch.nn.Tanh()

    def __init__(self, c1, c2, k=3, s=1, p=None, g=1, d=1, act=True, bn=True):
        super().__init__()
        self.m_conv = torch.nn.Conv3d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.m_bn = torch.nn.BatchNorm3d(c2) if bn is True else torch.nn.Identity()
        # self.m_bn = torch.nn.Dropout(0.25)
        self.m_act = self.default_act if act is True else torch.nn.Identity()

    def forward(self, x):
        return self.m_act(self.m_bn(self.m_conv(x)))

class Bottleneck(torch.nn.Module):
    def __init__(self, c1, c2, shortcut=True, g=1, k=(3, 3), e=0.5):
        super().__init__()
        c = int(c2 * e)
        self.m_conv_1 = Conv(c1, c, k[0], 1)
        self.m_conv_2 = Conv(c, c2, k[1], 1, g=g)
        self.m_add = shortcut and c1 == c2

    def forward(self, x):
        return x + self.m_conv_2(self.m_conv_1(x)) if self.m_add else self.m_conv_2(self.m_conv_1)

class C2f(torch.nn.Module):
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):
        super().__init__()
        self.m_c = int(c2 * e)
        self.m_conv_1 = Conv(c1, 2 * self.m_c, 1, 1)
        self.m_conv_2 = Conv((2 + n) * self.m_c, c2, 1)
        self.m_ml = torch.nn.ModuleList(Bottleneck(self.m_c, self.m_c, shortcut, g, k=((1, 3, 3), (1, 3, 3)), e=1.0)
                                        for _ in range(n))

    def forward(self, x):
        y = list(self.m_conv_1(x).split((self.m_c, self.m_c), 1))
        y.extend(ml(y[-1]) for ml in self.m_ml)
        return self.m_conv_2(torch.cat(y, 1))

class FM_FCN_3D_YOLO(torch.nn.Module):
    def __init__(self, in_channels=3, out_channels=4, n_frames=256):
        super().__init__()
        self.m_first_block = torch.nn.Sequential(
            Conv(in_channels, out_channels, k=(3, 3, 3), s=(1, 2, 2)),
            C2f(out_channels, out_channels, n=1, shortcut=True),
            Conv(out_channels, out_channels * 2, k=(3, 3, 3), s=(1, 2, 2)),
            C2f(out_channels * 2, out_channels * 2, n=1, shortcut=True),
            Conv(out_channels * 2, out_channels * 4, k=(3, 3, 3), s=(1, 2, 2)),
            C2f(out_channels * 4, out_channels * 4, n=1, shortcut=True),
            Conv(out_channels * 4, out_channels * 8, k=(3, 3, 3), s=(1, 2, 2)),
            C2f(out_channels * 8, out_channels * 8, n=1, shortcut=True),
        )
        self.m_adapt_avg_pool = torch.nn.AdaptiveAvgPool3d(output_size=(n_frames, 1, 1))
        self.m_filter_block = FilterBlock(out_channels * 8, out_channels * 4)

    def forward(self, x):
        out = self.m_first_block(x)
        out = self.m_adapt_avg_pool(out).squeeze()
        out = self.m_filter_block(out)
        return out

class FilterBlock(torch.nn.Module):
    def __init__(self, in_channel, out_channel):
        super().__init__()
        self.m_filter_1 = torch.nn.Sequential(
            torch.nn.Conv1d(in_channels=in_channel,
                            out_channels=out_channel,
                            kernel_size=3,
                            padding=1),
            torch.nn.Tanh(),
        )
        self.m_filter_2 = torch.nn.Sequential(
            torch.nn.Conv1d(in_channels=out_channel,
                            out_channels=1,
                            kernel_size=3,
                            padding=1),
            torch.nn.Flatten(),
        )

    def forward(self, x):
        x = self.m_filter_1(x)
        x = self.m_filter_2(x)
        return x


class AttentionBlock(torch.nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.attention = torch.nn.Conv3d(in_channels, 1, kernel_size=1, padding=0)

    def forward(self, input):
        mask = self.attention(input)
        mask = torch.sigmoid(mask)
        B, C, T, H, W = input.shape
        norm = 2 * torch.norm(mask, p=1, dim=(1, 3, 4))
        norm = norm.reshape(B, 1, T, 1, 1)
        mask = torch.div(mask * H * W, norm)
        return mask


if __name__ == '__main__':
    from utils.utils import weights_init
    import time
    device = torch.device(
        "cuda:0" if torch.cuda.is_available() else "cpu"
    )
    # img = torch.rand(256, 2, 3, 72, 72).to(device)  # [batch, norm + diff, channel, width, height]
    img = torch.rand(4, 3, 256, 36, 36).to(device)
    net = FM_FCN_3D_YOLO(out_channels=16).to(device)
    weights_init(net)
    out = net(img)  # [batch, 1]
    t1 = time.time()
    for _ in range(100):
        out = net(img)  # [batch, 1]
    t2 = time.time()
    print((t2 - t1) / 100)
    flops, params = profile(net, inputs=(img,))
    print(flops)
    print(params)