"""Unsupervised learning methods including POS, GREEN, CHROME, ICA, LGI and PBV."""

import logging
import os
import time
from collections import OrderedDict

import numpy as np
import torch
# from evaluation.post_process import *
from tradition.methods.CHROME_DEHAAN import *
from tradition.methods.GREEN import *
from tradition.methods.ICA_POH import *
from tradition.methods.LGI import *
from tradition.methods.PBV import *
from tradition.methods.POS_WANG import *
from tqdm import tqdm
from utils.get_hr import EvaluateHR

def unsupervised_predict(data_loader, method_name, data_name, fs=30):
    print("===Unsupervised Method ( " + method_name + " ) Predicting ===")
    time.sleep(1)
    EvalHR = EvaluateHR(mode='CONT')
    with tqdm(total=len(data_loader), desc=f'[Valid]', ncols=100, postfix=dict, mininterval=0.3) as pbar:
        for i in range(len(data_loader)):
            data_input, labels_input = data_loader[i]
            pbar.update(1)
            # data_input, labels_input = test_batch[0], test_batch[1]
            if method_name == "POS":
                BVP = POS_WANG(data_input, fs)
            elif method_name == "CHROM":
                BVP = CHROME_DEHAAN(data_input, fs)
            elif method_name == "ICA":
                BVP = ICA_POH(data_input, fs)
            elif method_name == "GREEN":
                BVP = GREEN(data_input)
            elif method_name == "LGI":
                BVP = LGI(data_input)
            elif method_name == "PBV":
                BVP = PBV(data_input)
            else:
                raise ValueError("unsupervised method name wrong!")

            EvalHR.add_data(BVP, labels_input)
    hr_loss = EvalHR.get_loss()
    for key in hr_loss:
        print(f"\t{key}: {hr_loss[key]:.4f}")

    pred_signal, real_signal, pred_hr, real_hr = EvalHR.get_result()

    save_data = {
        'pred_signal': pred_signal,
        'real_signal': real_signal,
        'pred_hr': pred_hr,
        'real_hr': real_hr,
        'hr_loss': hr_loss
    }
    from scipy.io import savemat
    savemat(method_name + '-' + data_name + '-' + '.mat', save_data)

if __name__ == '__main__':
    from tradition.data_loader import RppgDataset
    METHODS = ['POS', 'CHROM', 'ICA', 'GREEN', 'LGI', 'PBV']
    # METHODS = ['CHROM']
    mask = 'cheek'
    data_list = {
        'RLAP': "..\\..\\datasets\\RLAP\\proc09_no_y_range_ext_36_mask\\val",
        'PURE': "..\\..\\datasets\\PURE\\proc09_no_y_range_ext_36_mask",
        'UBFC-RPPG': "..\\..\\datasets\\UBFC-rppg\\proc09_no_y_range_ext_36_mask",
        'cohface': "..\\..\\datasets\\cohface\\proc09_no_y_range_ext_36_mask"
    }
    for method in METHODS:
        for data_name in data_list:
            dataset = RppgDataset([data_list[data_name]], 36, 256, mask=mask)
            unsupervised_predict(dataset, method, data_name, fs=30)

