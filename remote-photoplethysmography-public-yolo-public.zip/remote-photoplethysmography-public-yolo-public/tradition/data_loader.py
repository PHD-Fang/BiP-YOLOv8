import numpy as np
import torch
from torch.utils.data import Dataset
import os, cv2
import h5py


class RppgDataset(Dataset):
    def __init__(self, dir_path_list, img_size, length=1, overlap=0, mask=''):
        self.m_dir_path_list = dir_path_list        # 数据集路径
        self.m_img_size = img_size                  # 图像尺寸
        self.m_length = length
        self.m_overlap = overlap
        self.m_eye_mask = mask
        st = 0
        ed = 1
        # ---------------------------------------------------------------------#
        #   获取所有数据文件
        # ---------------------------------------------------------------------#
        self.m_file_list = []
        for dir_path in dir_path_list:
            curr_file_list = [dir_path + '/' + filename for filename in os.listdir(dir_path) if
                              filename.endswith('.hdf5')]
            curr_file_list.sort()
            curr_file_list = curr_file_list[int(st * len(curr_file_list)):int(ed * len(curr_file_list))]
            self.m_file_list.extend(curr_file_list)

        self.m_video_index = {}
        self.m_total_num = 0
        for filename in self.m_file_list:
            data = h5py.File(filename, "r")
            frames = data['raw_video'].shape[0] - 1
            num = int((frames - overlap) / (length - overlap))
            self.m_video_index[filename] = {'st': self.m_total_num, 'ed': self.m_total_num + num}
            self.m_total_num += num
            data.close()

    def getFileByIndex(self, index):
        aim_filename = ""
        for filename in self.m_video_index:
            if self.m_video_index[filename]['st'] <= index < self.m_video_index[filename]['ed']:
                aim_filename = filename
                break
        return aim_filename

    def __getitem__(self, index):
        index %= self.m_total_num
        filename = self.getFileByIndex(index)

        st = (index - self.m_video_index[filename]['st']) * (self.m_length - self.m_overlap)


        data = h5py.File(filename, "r")

        raw_video = data['raw_video'][st:st + self.m_length]
        ppg_data = data['ppg_data'][st:st + self.m_length]

        if self.m_eye_mask != '':
            if self.m_eye_mask == 'all':
                for mask_name in ['raw_mask_eye', 'raw_mask_mouth', 'raw_mask_nose']:
                    raw_mask = data[mask_name][st:st + self.m_length + 1]
                    for i in range(len(raw_video)):
                        raw_video[i] = cv2.subtract(raw_video[i], raw_mask[i])
            else:
                remove = False
                if 'remove' in self.m_eye_mask:
                    remove = True
                if 'eye' in self.m_eye_mask:
                    mask_name = 'raw_mask_eye'
                elif 'nose' in self.m_eye_mask:
                    mask_name = 'raw_mask_nose'
                elif 'mouth' in self.m_eye_mask:
                    mask_name = 'raw_mask_mouth'
                elif 'forehead' in self.m_eye_mask:
                    mask_name = 'raw_mask_forehead'
                elif 'cheek' in self.m_eye_mask:
                    mask_name = 'raw_mask_cheek'
                else:
                    raise EOFError("mask error")
                raw_mask = data[mask_name][st:st + self.m_length + 1]
                for i in range(len(raw_video)):
                    if remove:
                        raw_video[i] = cv2.subtract(raw_video[i], raw_mask[i])
                    else:
                        temp = cv2.subtract(raw_video[i], raw_mask[i])
                        raw_video[i] = cv2.subtract(raw_video[i], temp)


        video_data = raw_video[:, :, :, [2, 1, 0]]

        data.close()
        return video_data, ppg_data

    def __len__(self):
        return self.m_total_num


if __name__ == '__main__':
    import matplotlib.pyplot as plt
