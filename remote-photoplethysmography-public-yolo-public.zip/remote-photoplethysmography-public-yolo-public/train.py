import os
from tqdm import tqdm
import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from utils.utils import weights_init, get_lr_scheduler, set_optimizer_lr, get_lr
from utils.loss import loss_fn
from datasets.rppg_dataset import RppgDataset
from utils.get_hr import EvaluateHR
import time
import yaml

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

device = torch.device('cuda:0')

if __name__ == '__main__':
    config_file = r"config/TRAIN_EFFICIENT_cheek.yaml"

    # ---------------------------------------------------------------------#
    #   config
    # ---------------------------------------------------------------------#
    with open(config_file, 'r', encoding='utf-8') as f:
        config = yaml.load(f.read(), Loader=yaml.FullLoader)

    # ---------------------------------------------------------------------#
    #   init
    # ---------------------------------------------------------------------#
    log_dir = config["WORK_PATH"]
    work_name = time.strftime("%Y-%m-%d %H.%M.%S", time.localtime()) + '_' + config['MODEL']['NAME'] + '_' + config['TRAIN']['DATA']['PREPROCESS']['EYE_MASK']
    save_dir = log_dir + '/' + work_name + "/"
    if not os.path.exists(log_dir):
        os.mkdir(log_dir)
    if not os.path.exists(save_dir):
        os.mkdir(save_dir)
    with open(save_dir + "log.txt", 'w+') as f:
        yaml.dump(config, f, allow_unicode=True, default_flow_style=False)
    # ---------------------------------------------------------------------#
    #   build model
    # ---------------------------------------------------------------------#
    model_name = config['MODEL']['NAME']
    if model_name == 'FM_FCN_3D_YOLO':
        from nets.FM_FCN_3D_YOLO import FM_FCN_3D_YOLO
        model = FM_FCN_3D_YOLO(in_channels=3, out_channels=8)
    elif model_name == 'CAN':
        from nets.CAN import CAN
        model = CAN(3, 32, 64)
    elif model_name == 'TSCAN':
        from nets.TS_CAN import TS_CAN
        model = TS_CAN(img_size=config['VAL']['DATA']['PREPROCESS']['IMG_SIZE'])
    elif model_name == 'PHYSNET':
        from nets.PhysNet import PhysNet
        model = PhysNet()
    elif model_name == 'BIG_SMALL':
        from nets.BigSmall import BigSmallWTSM
        model = BigSmallWTSM()
    elif model_name == 'EFFICIENT':
        from nets.EfficientPhys_Conv import EfficientPhys_Conv
        model = EfficientPhys_Conv(img_size=config['TRAIN']['DATA']['PREPROCESS']['IMG_SIZE'], frame_depth=32, channel=
                                   config['TRAIN']['DATA']['PREPROCESS']['MODE'])
    else:
        raise ValueError(f'不支持{model_name}模型！')
    weights_init(model)
    # model.load_state_dict(torch.load(
    #     config['MODEL']['WEIGHT_PATH'], map_location=device))
    model = model.to(device)

    # ---------------------------------------------------------------------#
    #    build dataset
    # ---------------------------------------------------------------------#
    train_dataset = RppgDataset(config['TRAIN']['DATA']['DATA_PATH'],
                                config['TRAIN']['DATA']['PREPROCESS']['IMG_SIZE'],
                                config['TRAIN']['DATA']['PREPROCESS']['TIME_LENGTH'],
                                config['TRAIN']['DATA']['PREPROCESS']['OVERLAP'],
                                config['TRAIN']['DATA']['ST'],
                                config['TRAIN']['DATA']['ED'],
                                True,
                                config['TRAIN']['DATA']['PREPROCESS']['MODE'],
                                diff_norm=config['TRAIN']['DATA']['PREPROCESS']['DIFF_NORM_METHOD'],
                                video_norm_per_channel=config['TRAIN']['DATA']['PREPROCESS']['VIDEO_NORM_PER_CHANNEL'],
                                eye_mask=config['TRAIN']['DATA']['PREPROCESS']['EYE_MASK'])
    train_loader = DataLoader(train_dataset, shuffle=True, batch_size=config['TRAIN']['BATCH_SIZE'],
                              num_workers=config['DEVICE']['NUM_WORKERS'], pin_memory=True, drop_last=True)

    val_loader_list = []
    for i in range(len(config['VAL']['DATA']['DATA_NAME'])):
        val_dataset = RppgDataset([config['VAL']['DATA']['DATA_PATH'][i]],
                                  config['VAL']['DATA']['PREPROCESS']['IMG_SIZE'],
                                  config['VAL']['DATA']['PREPROCESS']['TIME_LENGTH'],
                                  config['VAL']['DATA']['PREPROCESS']['OVERLAP'],
                                  config['VAL']['DATA']['ST'],
                                  config['VAL']['DATA']['ED'],
                                  False,
                                  config['VAL']['DATA']['PREPROCESS']['MODE'],
                                  diff_norm=config['VAL']['DATA']['PREPROCESS']['DIFF_NORM_METHOD'],
                                  video_norm_per_channel=config['VAL']['DATA']['PREPROCESS']['VIDEO_NORM_PER_CHANNEL'],
                                  eye_mask=config['TRAIN']['DATA']['PREPROCESS']['EYE_MASK'])
        val_loader = DataLoader(val_dataset, shuffle=False, batch_size=config['VAL']['BATCH_SIZE'],
                                num_workers=config['DEVICE']['NUM_WORKERS'], pin_memory=True, drop_last=True)
        val_loader_list.append(val_loader)

    # ---------------------------------------------------------------------#
    #   build loss
    # ---------------------------------------------------------------------#
    loss_func = loss_fn(config['TRAIN']['LOSS_TYPE'])
    hr_loss = loss_fn('hr_loss')

    # ---------------------------------------------------------------------#
    #   train and val steps
    # ---------------------------------------------------------------------#
    train_epoch_step = len(train_loader)

    # ---------------------------------------#
    #   select optimizer
    # ---------------------------------------#
    init_lr = config['TRAIN']['INIT_LR']
    optim_name = config['TRAIN']['OPTIMIZER_TYPE']
    if optim_name == 'adam':
        optimizer = optim.Adam(model.parameters(), init_lr)
    elif optim_name == 'adamw':
        optimizer = optim.AdamW(model.parameters(), init_lr)
    elif optim_name == 'sgd':
        optimizer = optim.SGD(model.parameters(), init_lr, momentum=0.937, nesterov=True)
    else:
        raise ValueError(f'不支持{optim_name}优化器！')

    # ---------------------------------------#
    #   select lr decay type
    # ---------------------------------------#
    min_lr = config['TRAIN']['MIN_LR']
    lr_decay_type = config['TRAIN']['LR_DECAY_TYPE']
    epochs = config['TRAIN']['EPOCHS']
    lr_scheduler_func = get_lr_scheduler(lr_decay_type, init_lr, min_lr, epochs)

    for epoch in range(epochs):
        # ---------------------------------------------------------------------#
        #    modify lr
        # ---------------------------------------------------------------------#
        set_optimizer_lr(optimizer, lr_scheduler_func, epoch)
        # ---------------------------------------------------------------------#
        #   start training
        # ---------------------------------------------------------------------#
        train_loss = 0
        _curve_loss = 0
        _hr_loss = 0
        model.train()
        with tqdm(total=train_epoch_step, desc=f'[Train] {model_name} Epoch {epoch + 1}/{epochs}', ncols=150, postfix=dict,
                  mininterval=0.3) as pbar:
            for iteration, batch in enumerate(train_loader):
                videos, labels = batch[0], batch[1]
                with torch.no_grad():
                    videos = videos.to(device)
                    labels = labels.to(device)
                optimizer.zero_grad()
                outputs = model(videos)
                loss_value = loss_func(outputs, labels)
                loss_value.backward()
                train_loss += loss_value.item()
                pbar.set_postfix(**{'loss': train_loss / (iteration + 1),
                                    'lr': get_lr(optimizer)})
                optimizer.step()
                pbar.update(1)
                # break
        with open(save_dir + "log.txt", 'a+') as f:
            f.write(f"Epoch {epoch + 1}, ")
            f.write(f"loss: {train_loss / train_epoch_step:.4f}\n")
        if epoch > 40:

            # ---------------------------------------------------------------------#
            #   start val
            # ---------------------------------------------------------------------#
            model.eval()
            for i in range(len(config['VAL']['DATA']['DATA_NAME'])):
                val_name = config['VAL']['DATA']['DATA_NAME'][i]
                # ---------------------------------------------------------------------#
                #   heart rate evaluator
                # ---------------------------------------------------------------------#
                EvalHR = EvaluateHR(mode=config['TRAIN']['DATA']['PREPROCESS']['MODE'],
                                    fs=config['VAL']['DATA']['FS'][i])
                val_epoch_step = len(val_loader_list[i])
                EvalHR.clear()
                val_loss = 0
                _val_curve_loss = 0
                _val_hr_loss = 0
                with tqdm(total=val_epoch_step, desc=f'\t[Valid] {model_name} {val_name} Epoch {epoch + 1}/{epochs}',
                          ncols=150, postfix=dict, mininterval=0.3) as pbar:
                    for iteration, batch in enumerate(val_loader_list[i]):
                        videos, labels = batch[0], batch[1]
                        with torch.no_grad():
                            videos = videos.to(device)
                            labels = labels.to(device)

                        outputs = model(videos)
                        loss_value = loss_func(outputs, labels)
                        val_loss += loss_value.item()
                        pbar.set_postfix(**{'loss': val_loss / (iteration + 1)})
                        # ---------------------------------------------------------------------#
                        #   cal heart rate
                        # ---------------------------------------------------------------------#
                        outputs = outputs.detach().cpu().numpy()
                        labels = labels.detach().cpu().numpy()
                        if config['VAL']['BATCH_SIZE'] >= 1:
                            for ii in range(len(labels)):
                                EvalHR.add_data(outputs[ii], labels[ii])
                        else:
                            EvalHR.add_data(outputs, labels)

                        # pbar.set_postfix(**{'loss': val_loss / (iteration + 1)})
                        pbar.update(1)
                        # break
                print(f'\t{val_name}\tVal Loss: {val_loss / val_epoch_step:.4f} ')

                # ---------------------------------------------------------------------#
                #   metrics
                # ---------------------------------------------------------------------#
                eval_hr_loss = EvalHR.get_loss()
                hr_str = ""
                for key in eval_hr_loss:
                    print(f"\t{key}: {eval_hr_loss[key]:.4f}", end='')
                    hr_str += f"-{key}[{eval_hr_loss[key]:.4f}]"
                print(end='\n')
                with open(save_dir + "log.txt", 'a+') as f:
                    f.write(f"\t{val_name}_loss: {val_loss / val_epoch_step:.4f}")
                    for key in eval_hr_loss:
                        f.write(f", {key}: {eval_hr_loss[key]:.4f}")
                    f.write("\n")

                pred_signal, real_signal, pred_hr, real_hr = EvalHR.get_result()
                save_data = {
                    'pred_signal': pred_signal,
                    'real_signal': real_signal,
                    'pred_hr': pred_hr,
                    'real_hr': real_hr,
                    'hr_loss': hr_loss
                }
                from scipy.io import savemat

                savemat(save_dir + '/' + str(epoch) + '-' + model_name + '-' + val_name + '-' + str(
                    config['VAL']['DATA']['PREPROCESS']['TIME_LENGTH']) + '-' + config['TRAIN']['DATA']['PREPROCESS'][
                            'EYE_MASK'] + '.mat', save_data)

        # ---------------------------------------------------------------------#
        #   save
        # ---------------------------------------------------------------------#
        save_state_dict = model.state_dict()
        torch.save(save_state_dict, os.path.join(save_dir, "ep%03d.pth" % epoch))
